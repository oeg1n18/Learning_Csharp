﻿using System;

namespace loops
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            for (int i = 0; i<5; i++) {
                Console.WriteLine(i);
            }
        }
    }
}
