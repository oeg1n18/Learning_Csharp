﻿using System;

namespace Constants
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            // Constants and Literals are the 

            const string hellow0rld = "hello world constant string";
            const float pi = 3.14159F;
            const string stringliteral = @"these \n will not produce a new line";

        }
    }
}
