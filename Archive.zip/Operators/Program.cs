﻿using System;

namespace Operators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            int A = 2;
            int B = 4;
            int C = A + B;
            C++; //c = c+1 //all pretty similar to C/C++ operations.
        }
    }
}
